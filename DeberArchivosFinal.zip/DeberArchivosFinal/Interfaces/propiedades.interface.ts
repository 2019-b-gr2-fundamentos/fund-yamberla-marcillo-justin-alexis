export interface propiedadesMarca{
    id: number;
    nombre: string;
    color: string;
    talla: string;
    precio: string;
    categoria: number;
}